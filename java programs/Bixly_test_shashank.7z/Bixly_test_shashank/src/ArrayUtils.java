
abstract class ArrayUtils {
	
	
	abstract void GenerateArray();
	abstract void DisplayArray();
	abstract void RemoveDuplicate();
	abstract void Sorting();
    abstract void consicutive();
}
